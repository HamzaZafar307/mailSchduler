package com.example.demo;

import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;

public class EmailJob implements Job {

    @Autowired
    private JavaMailSender javaMailSender;

    @Override
    public void execute(JobExecutionContext context) throws JobExecutionException {
        SimpleMailMessage msg = new SimpleMailMessage();
        msg.setTo("hamzazafar99p@gmail.com");
        msg.setSubject("Test Email");
        msg.setText("Hi, This is a test email sent using Spring Boot and Quartz Scheduler.");
        javaMailSender.send(msg);
    }

}
