/*
package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;

@Service
public class EmailService {

    @Autowired
    private JavaMailSender javaMailSender;

    public void sendEmail() {
        SimpleMailMessage msg = new SimpleMailMessage();
        msg.setTo("anas.azam40@gmail.com");
        msg.setSubject("Test Email");
        msg.setText("Hi, This is a test email sent using Spring Boot and JavaMailSender.");
        javaMailSender.send(msg);
    }

}
*/
